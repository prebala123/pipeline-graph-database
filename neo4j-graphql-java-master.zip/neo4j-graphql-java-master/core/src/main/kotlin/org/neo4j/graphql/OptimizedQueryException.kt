package org.neo4j.graphql

class OptimizedQueryException(message: String) : Exception(message)